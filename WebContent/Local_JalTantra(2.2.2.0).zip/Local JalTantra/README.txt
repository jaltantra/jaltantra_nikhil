VERSION: 2.2.1.0
This local version of JalTantra is for offline use or in case of the JalTantra site being down.

jaltantra_local.exe is the executable file which starts a local server at localhost:8080
Run the exe file and a console should popup showing the server startup
Now goto the browser and type in http://localhost:8080/jaltantra/ to access the local web version of JalTantra

NOTE: You still need internet access if you wish to use the map functionality since it needs to connect to the google servers

For the online version of JalTantra visit : www.cse.iitb.ac.in/jaltantra
For further information about JalTantra visit : www.cse.iitb.ac.in/~nikhilh/jaltantra
Join the JalTantra Google Group at https://groups.google.com/forum/#!forum/jaltantra-users/join for any discussion regarding JalTantra
For any queries or suggestion please mail hooda.nikhil@gmail.com